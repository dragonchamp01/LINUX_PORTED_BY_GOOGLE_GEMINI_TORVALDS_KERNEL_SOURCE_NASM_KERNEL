#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

struct fixed31_32 {
    long long value;
};

extern struct fixed31_32 dc_fixpt_from_int_asm(int arg);
extern struct fixed31_32 dc_fixpt_neg_asm(struct fixed31_32 arg);
extern struct fixed31_32 dc_fixpt_add_asm(struct fixed31_32 arg1, struct fixed31_32 arg2);
extern struct fixed31_32 dc_fixpt_sub_asm(struct fixed31_32 arg1, struct fixed31_32 arg2);
extern struct fixed31_32 dc_fixpt_mul_asm(struct fixed31_32 arg1, struct fixed31_32 arg2);
extern struct fixed31_32 dc_fixpt_recip_asm(struct fixed31_32 arg);

void print_fixpt(const char *name, struct fixed31_32 f) {
    double d = (double)f.value / (1LL << 32);
    printf("%s: %f (0x%llx)\n", name, d, f.value);
}

int main() {
    struct fixed31_32 a = dc_fixpt_from_int_asm(5);
    struct fixed31_32 b = dc_fixpt_from_int_asm(2);
    
    print_fixpt("a (5)", a);
    print_fixpt("b (2)", b);
    
    struct fixed31_32 sum = dc_fixpt_add_asm(a, b);
    print_fixpt("a + b", sum);
    
    struct fixed31_32 prod = dc_fixpt_mul_asm(a, b);
    print_fixpt("a * b", prod);
    
    struct fixed31_32 half = { 0x80000000LL }; // 0.5
    print_fixpt("0.5", half);
    
    struct fixed31_32 a_half = dc_fixpt_mul_asm(a, half);
    print_fixpt("a * 0.5", a_half);
    
    struct fixed31_32 inv_a = dc_fixpt_recip_asm(a);
    print_fixpt("1/a", inv_a);
    
    return 0;
}
