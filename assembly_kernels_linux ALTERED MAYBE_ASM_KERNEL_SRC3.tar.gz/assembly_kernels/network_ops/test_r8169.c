#include <stdio.h>
#include <stdint.h>
#include <string.h>

struct TxDesc {
    uint32_t opts1;
    uint32_t opts2;
    uint64_t addr;
};

extern void rtl8169_set_desc_asm(struct TxDesc *d, uint32_t opts1, uint32_t opts2, uint64_t addr);
extern void rtl8169_mark_desc_own_asm(struct TxDesc *d, uint32_t opts1_mask);

int main() {
    struct TxDesc d;
    memset(&d, 0, sizeof(d));
    
    printf("Setting descriptor...\n");
    rtl8169_set_desc_asm(&d, 0x12345678, 0xABCDEF01, 0xFEEDFACECAFEBEEF);
    
    printf("Result:\n");
    printf("  opts1: 0x%x (expected 0x12345678)\n", d.opts1);
    printf("  opts2: 0x%x (expected 0xABCDEF01)\n", d.opts2);
    printf("  addr:  0x%lx (expected 0xFEEDFACECAFEBEEF)\n", d.addr);
    
    printf("\nMarking ownership...\n");
    rtl8169_mark_desc_own_asm(&d, 0x80000000);
    printf("  opts1: 0x%x (expected 0x92345678)\n", d.opts1);

    return 0;
}
