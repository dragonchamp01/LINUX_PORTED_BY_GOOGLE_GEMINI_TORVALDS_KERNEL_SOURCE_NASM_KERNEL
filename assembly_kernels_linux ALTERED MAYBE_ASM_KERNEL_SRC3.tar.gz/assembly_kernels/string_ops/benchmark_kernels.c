#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

extern void *memcpy_avx(void *dest, const void *src, size_t n);
extern void *memset_avx(void *s, int c, size_t n);

#define BUFFER_SIZE (1024 * 1024 * 64) // 64MB
#define ITERATIONS 10

double get_time() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

int main() {
    void *src = malloc(BUFFER_SIZE);
    void *dest = malloc(BUFFER_SIZE);
    
    if (!src || !dest) {
        printf("Failed to allocate memory\n");
        return 1;
    }

    memset(src, 0xAA, BUFFER_SIZE);

    printf("--- Benchmarking Memcpy (64MB, %d iterations) ---\n", ITERATIONS);
    
    double start = get_time();
    for (int i = 0; i < ITERATIONS; i++) {
        memcpy(dest, src, BUFFER_SIZE);
    }
    double end = get_time();
    printf("Standard libc memcpy: %.4f seconds\n", (end - start) / ITERATIONS);

    start = get_time();
    for (int i = 0; i < ITERATIONS; i++) {
        memcpy_avx(dest, src, BUFFER_SIZE);
    }
    end = get_time();
    printf("Custom ERMS memcpy:   %.4f seconds\n", (end - start) / ITERATIONS);

    printf("\n--- Benchmarking Memset (64MB, %d iterations) ---\n", ITERATIONS);

    start = get_time();
    for (int i = 0; i < ITERATIONS; i++) {
        memset(dest, 0xBB, BUFFER_SIZE);
    }
    end = get_time();
    printf("Standard libc memset: %.4f seconds\n", (end - start) / ITERATIONS);

    start = get_time();
    for (int i = 0; i < ITERATIONS; i++) {
        memset_avx(dest, 0xBB, BUFFER_SIZE);
    }
    end = get_time();
    printf("Custom ERMS memset:   %.4f seconds\n", (end - start) / ITERATIONS);

    free(src);
    free(dest);
    return 0;
}
