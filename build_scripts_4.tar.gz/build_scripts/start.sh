gemini --include-directories /media/marco/e-learning/GEMINI_WORK_DIR/

