import os

UPSTREAM_ROOT = "/media/marco/e-learning/linus_sources/linux"

# 1. Patch AMDGPU basics Makefile
basics_makefile = os.path.join(UPSTREAM_ROOT, "drivers/gpu/drm/amd/display/dc/basics/Makefile")
if os.path.exists(basics_makefile):
    with open(basics_makefile, 'r') as f:
        content = f.read()
    if 'dc_fixpt_nasm.o' not in content:
        content = content.replace('fixpt31_32.o \\', 'fixpt31_32.o \\\n\tdc_fixpt_nasm.o \\')
        content += '\n# NASM Rule for Kbuild\n$(obj)/dc_fixpt_nasm.o: $(src)/dc_fixpt_nasm.asm\n\tnasm -f elf64 $< -o $@\n'
        with open(basics_makefile, 'w') as f:
            f.write(content)

# 2. Patch AMDGPU driver Makefile
amdgpu_makefile = os.path.join(UPSTREAM_ROOT, "drivers/gpu/drm/amd/amdgpu/Makefile")
if os.path.exists(amdgpu_makefile):
    with open(amdgpu_makefile, 'r') as f:
        lines = f.readlines()
    with open(amdgpu_makefile, 'w') as f:
        for line in lines:
            if 'amdgpu-y :=' in line and 'amdgpu_drv.o' in line and 'amdgpu_ih_nasm.o' not in line:
                line = line.replace('amdgpu_drv.o', 'amdgpu_drv.o amdgpu_ih_nasm.o')
            f.write(line)
        f.write('\n# NASM Rule for amdgpu\n$(obj)/amdgpu_ih_nasm.o: $(src)/amdgpu_ih_nasm.asm\n\t@echo "  NASM    $@"\n\tnasm -f elf64 $< -o $@\n')

print("Upstream Makefiles patched.")
