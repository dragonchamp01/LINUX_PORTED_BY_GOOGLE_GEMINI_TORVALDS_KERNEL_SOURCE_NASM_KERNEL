#!/bin/bash
UPSTREAM_DIR="/media/marco/e-learning/GEMINI_WORK_DIR/upstream_linux"
mkdir -p "$UPSTREAM_DIR"
cd "$UPSTREAM_DIR"

echo "Downloading latest Linux Kernel tarball..."
wget -c https://github.com/torvalds/linux/archive/refs/heads/master.tar.gz -O linux-master.tar.gz

echo "Extracting..."
tar -xzf linux-master.tar.gz --strip-components=1
rm linux-master.tar.gz

echo "Analyzing for Assembly Ports..."
find . -name "*.S" | wc -l | xargs echo "GAS Assembly files found:"
find . -name "*.asm" | wc -l | xargs echo "NASM Assembly files found (likely 0 in upstream):"

echo "Sync Complete."
