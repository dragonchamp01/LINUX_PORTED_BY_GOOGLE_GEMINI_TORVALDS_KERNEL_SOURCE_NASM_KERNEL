#!/bin/bash
EXTS=(
    "https://github.com/blacktop/ipsw-skill"
    "https://github.com/naieum/Snitch"
    "https://github.com/automateyournetwork/GeminiCLI_Packet_Buddy_Extension"
)

for ext in "${EXTS[@]}"; do
    echo "Installing $ext..."
    yes | gemini extensions install "$ext"
done
