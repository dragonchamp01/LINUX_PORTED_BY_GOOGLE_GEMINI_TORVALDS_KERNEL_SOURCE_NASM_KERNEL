#!/bin/bash
# inject_nasm_ports.sh - Inject hand-optimized NASM routines into upstream kernel

UPSTREAM_ROOT="/media/marco/e-learning/GEMINI_WORK_DIR/upstream_linux"
PORTS_ROOT="/media/marco/e-learning/GEMINI_WORK_DIR/work_source_code/kernel_source"

echo "=== Injecting NASM ports into Upstream Kernel ==="

# 1. AMDGPU Display Math
echo "[1/3] Injecting AMDGPU Display Math..."
cp "$PORTS_ROOT/drivers/gpu/drm/amd/display/dc/basics/dc_fixpt_nasm.asm" "$UPSTREAM_ROOT/drivers/gpu/drm/amd/display/dc/basics/"
cp "$PORTS_ROOT/drivers/gpu/drm/amd/display/include/fixed31_32_nasm.h" "$UPSTREAM_ROOT/drivers/gpu/drm/amd/display/include/"

# 2. AMDGPU Interrupt Handler
echo "[2/3] Injecting AMDGPU ISR..."
cp "$PORTS_ROOT/drivers/gpu/drm/amd/amdgpu/amdgpu_ih_nasm.asm" "$UPSTREAM_ROOT/drivers/gpu/drm/amd/amdgpu/"
cp "$PORTS_ROOT/drivers/gpu/drm/amd/amdgpu/amdgpu_ih_nasm.h" "$UPSTREAM_ROOT/drivers/gpu/drm/amd/amdgpu/"

# 3. Boot Memory Ops
echo "[3/3] Injecting Boot Ops..."
# Note: We need a specialized Makefile rule for this in arch/x86/boot/
cp "/media/marco/e-learning/GEMINI_WORK_DIR/work_source_code/assembly_kernels/boot_ops_nasm.asm" "$UPSTREAM_ROOT/arch/x86/boot/"

echo "Port injection complete."
