#!/bin/bash
# switch_to_linus_tree.sh - Move NASM ports to the official Linus Torvalds tree

LINUS_ROOT="/media/marco/e-learning/linus_sources/linux"
PORTS_ROOT="/media/marco/e-learning/GEMINI_WORK_DIR/work_source_code/kernel_source"
CONFIG_FILE="/media/marco/e-learning/GEMINI_WORK_DIR/kernel_configs/config-nasm-optimized"

echo "=== Overstappen naar de officiële Linus Torvalds bronboom ==="

if [ ! -d "$LINUS_ROOT" ]; then
    echo "Fout: Linus tree niet gevonden op $LINUS_ROOT"
    exit 1
fi

# 1. Injecteer NASM bronbestanden
echo "[1/4] Injecteren van NASM bestanden..."
cp "$PORTS_ROOT/drivers/gpu/drm/amd/display/dc/basics/dc_fixpt_nasm.asm" "$LINUS_ROOT/drivers/gpu/drm/amd/display/dc/basics/"
cp "$PORTS_ROOT/drivers/gpu/drm/amd/display/include/fixed31_32_nasm.h" "$LINUS_ROOT/drivers/gpu/drm/amd/display/include/"
cp "$PORTS_ROOT/drivers/gpu/drm/amd/amdgpu/amdgpu_ih_nasm.asm" "$LINUS_ROOT/drivers/gpu/drm/amd/amdgpu/"
cp "$PORTS_ROOT/drivers/gpu/drm/amd/amdgpu/amdgpu_ih_nasm.h" "$LINUS_ROOT/drivers/gpu/drm/amd/amdgpu/"
cp "/media/marco/e-learning/GEMINI_WORK_DIR/work_source_code/assembly_kernels/boot_ops_nasm.asm" "$LINUS_ROOT/arch/x86/boot/"

# 2. Kopieer configuratie
echo "[2/4] Configuratie overzetten..."
cp "$CONFIG_FILE" "$LINUS_ROOT/.config"

# 3. Patch scripts uitvoeren op de nieuwe locatie
echo "[3/4] Makefiles en code patchen..."
# We moeten de Python scripts aanpassen om naar de nieuwe LINUS_ROOT te kijken
sed -i "s|UPSTREAM_ROOT = .*|UPSTREAM_ROOT = \"$LINUS_ROOT\"|" work_source_code/build_scripts/patch_upstream_makefiles.py
sed -i "s|UPSTREAM_ROOT = .*|UPSTREAM_ROOT = \"$LINUS_ROOT\"|" work_source_code/build_scripts/patch_upstream_code.py

python3 work_source_code/build_scripts/patch_upstream_makefiles.py
python3 work_source_code/build_scripts/patch_upstream_code.py

# 4. Kconfig aanpassen (handmatig via sed in de nieuwe boom)
echo "[4/4] Kconfig updaten..."
# AMDGPU ISR
sed -i '36i config CONFIG_AMDGPU_IH_NASM\n\tbool "Use NASM optimized ISR for AMDGPU"\n\tdefault y\n\tdepends on DRM_AMDGPU && X86_64' "$LINUS_ROOT/drivers/gpu/drm/amd/amdgpu/Kconfig"
# AMDGPU DC
sed -i '22i config CONFIG_AMDGPU_DC_NASM\n\tbool "Use NASM optimized fixed-point math for AMDGPU DC"\n\tdefault y\n\tdepends on DRM_AMD_DC && X86_64' "$LINUS_ROOT/drivers/gpu/drm/amd/display/Kconfig"

echo "Klaar! De officiële Linus tree is nu geoptimaliseerd."
