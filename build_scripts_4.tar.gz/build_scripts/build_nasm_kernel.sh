#!/bin/bash
# build_nasm_kernel.sh - Build the NASM-optimized kernel

UPSTREAM_ROOT="/media/marco/e-learning/linus_sources/linux"
CONFIG_FILE="/media/marco/e-learning/GEMINI_WORK_DIR/kernel_configs/config-nasm-optimized"

cd "$UPSTREAM_ROOT"

echo "=== Kernel Build Gestart (NASM Optimization Enabled) ==="

# 1. Ensure config is up to date
cp "$CONFIG_FILE" .config
make olddefconfig

# 2. Compile (using all available cores)
# We add NASM=nasm to ensure the build system can see it
make -j$(nproc) NASM=nasm

if [ $? -eq 0 ]; then
    echo "Kernel build succesvol!"
    echo "De vmlinuz image staat in arch/x86/boot/bzImage"
else
    echo "Kernel build mislukt. Zie foutmeldingen hierboven."
fi
