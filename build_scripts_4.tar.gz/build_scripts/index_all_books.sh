#!/bin/bash

# Gemini Research Hub - 100% COVERAGE AGGRESSIVE RE-INDEXER
BASE_DIR="/media/marco/e-learning/GEMINI_WORK_DIR/research_hub"
INDEX_DIR="$BASE_DIR/text_index"
PLUGIN_DIR="/media/marco/e-learning/GEMINI_WORK_DIR/work_source_code/research_hub_source_codes"
PYTHON_BIN="python3"

echo "=== Gemini Ultimate RE-INDEXING Mode (50-page chunks) ==="
mkdir -p "$INDEX_DIR"

index_priority() {
    local folder="$1"
    local label="$2"
    local size_limit="$3"
    echo "--- [PRIO] Verwerken van $label ---"
    
    if [ ! -d "$folder" ]; then
        echo "  [FOUT] Map niet gevonden: $folder"
        return
    fi

    find "$folder" -type f -name "*.pdf" -size +"$size_limit" | while read -r pdf_file; do
        local base_name=$(basename "$pdf_file" .pdf | tr ' ' '_' | tr -d '()[]{}')
        
        echo "  [RE-INDEX] $pdf_file"
        
        # Cleanup old parts first to avoid mixing chunking logic
        rm -f "$INDEX_DIR/${base_name}_part_"*.txt
        
        # Run conversion
        $PYTHON_BIN "$PLUGIN_DIR/pdf_to_text.py" "$pdf_file" "$INDEX_DIR"
    done
}

# --- STAP 1: PRIORITEIT 1 (Quantum, AI, Math) ---
index_priority "$BASE_DIR/pdf files/QUANTUM MECHANICA" "Quantum Mechanica" "1M"
index_priority "$BASE_DIR/pdf files/programming/ARTIFICIAL INTELLIGENCE" "AI Books" "1M"
index_priority "$BASE_DIR/pdf files/programming/COMPUTER SCIENCE" "CS Books" "1M"
index_priority "$BASE_DIR/pdf files/wiskunde" "Wiskunde" "1M"
index_priority "$BASE_DIR/pdf files/university books" "University Books" "1M"

# --- STAP 2: PRIORITEIT 2 (General Programming) ---
index_priority "$BASE_DIR/pdf files/programming" "All Programming" "2M"

# --- STAP 3: NATUURKUNDE ---
index_priority "$BASE_DIR/pdf files/NATUURKUNDE" "Natuurkunde" "1M"

echo "=== RE-INDEXINGS-run voltooid! ==="
